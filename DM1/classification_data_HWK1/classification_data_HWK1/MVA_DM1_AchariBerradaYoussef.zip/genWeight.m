function [ w ] = genWeight( x )
%UNTITLED11 Summary of this function goes here
%   Detailed explanation goes here
    
    w = rand(size(x,2) + 1,1); 

end

